﻿namespace votingapp.Models
{
    public class Voter
    {
        public int id { get; set; }
        public string name { get; set; }
        public bool has_voted { get; set; }
    }
}
