﻿namespace votingapp.Models
{
    public class Candidate
    {
        public int id { get; set; }
        public string name { get; set; }
        public int votes { get; set; }
    }

}
